//
//  Notifications.swift
//  rabbit
//
//  Created by CYC on 2016/11/19.
//  Copyright © 2016年 yicheng. All rights reserved.
//

let kProxyServiceVPNStatusNotification = "kProxyServiceVPNStatusNotification"

